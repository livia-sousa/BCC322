#include "funcional_tests.hpp"

int main(){
    exponentialFuncionalTest();
    logisticalFuncionalTest();
    complexFuncionalTest();
    cout << "Passou pelos testes funcionais" << endl;
    return 0;
}
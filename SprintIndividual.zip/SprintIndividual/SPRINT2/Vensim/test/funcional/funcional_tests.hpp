
#include "../../src/model.hpp"
#include "../../src/system.hpp"
#include "../../src/flow.hpp"
#include "../../src/flowExponential.hpp"
#include "../../src/flowLogistic.hpp"
#include <assert.h>
#include <cmath>
#include <iostream>
#include <cstdlib>
#include <cstring>

#ifndef FUNCIONAL_TESTS
#define FUNCIONAL_TESTS

void exponentialFuncionalTest();
void logisticalFuncionalTest();
void complexFuncionalTest();

#endif
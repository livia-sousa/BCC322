

#ifndef MODEL_HPP
#define MODEL_HPP
#include <cstring>
#include <ostream>
#include <vector>
#include "flow.hpp"
#include "flowExponential.hpp"
#include "flowLogistic.hpp"
#include "system.hpp"
#include "model.hpp"

class Model{
protected:
    string name;
    vector<Flow*> flows;
    vector<System*> systems;
    
private:
    Model(Model& obj);
    Model& operator=(const Model& obj);

public:
    Model();
    Model(const string name);
    Model(const string name, vector<Flow*> &flows, vector<System*> &systems);
    virtual ~Model();

    typedef typename vector<Flow*>::iterator itFlow;
    typedef typename vector<System*>::iterator itSystem;
    
    string getName() const;
    void setName(const string name);

    itFlow getFlowBegin();
    itFlow getFlowEnd();
    int getFlowSize();

    itSystem getSystemBegin();
    itSystem getSystemEnd();
    int getSystemSize();    
         
    void add(System*);
    void add(Flow*);
    bool remove(System*);
    bool remove(Flow*);
    void clear();
    void show();
    void run(int, int, int);    

};

#endif
    

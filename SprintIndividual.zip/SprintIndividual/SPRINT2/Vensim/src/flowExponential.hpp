#ifndef FLOWEXPONENTIAL_HPP
#define FLOWEXPONENTIAL_HPP

#include "flow.hpp"

class FlowExponential:public Flow{
public:    
    FlowExponential();
    FlowExponential(Flow &obj);
    FlowExponential(const string name, System *origin, System *destiny);
    virtual ~FlowExponential();

    virtual float execute();  
};
#endif
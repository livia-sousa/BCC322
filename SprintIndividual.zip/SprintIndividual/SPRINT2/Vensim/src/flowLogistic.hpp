#ifndef FLOWLOGISTIC_HPP
#define FLOWLOGISTIC_HPP

#include "flow.hpp"

class FlowLogistic:public Flow{
public:    
    FlowLogistic();
    FlowLogistic(Flow &obj);
    FlowLogistic(const string name, System *origin, System *destiny);
    virtual ~FlowLogistic();

    virtual float execute();
};
#endif
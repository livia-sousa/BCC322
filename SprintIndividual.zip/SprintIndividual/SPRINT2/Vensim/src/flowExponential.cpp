#include "flowExponential.hpp"

FlowExponential::FlowExponential(){
    name = "NULL";
    origin = NULL;
    destiny = NULL;
}

FlowExponential::FlowExponential(Flow &obj){
    if(&obj == this)
        return;
    
    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
};

FlowExponential::FlowExponential(const string name, System *origin, System *destiny):Flow(name, origin, destiny){};
FlowExponential::~FlowExponential(){}

float FlowExponential::execute(){
    return getOrigin()->getValue() * 0.01;
};
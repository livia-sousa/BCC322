#ifndef FLOW_HPP
#define FLOW_HPP
#include <iostream>
#include <string>
#include "system.hpp"

class Flow{
protected:
    string name;
    System *origin;
    System *destiny;

public:

    Flow();
    Flow(Flow &obj);
    Flow(const string name, System *origin, System *destiny);
    virtual ~Flow();

    string getName() const;
    void setName(const string name);
    System *getOrigin() const;
    void setOrigin(System *origin);
    System *getDestiny() const;
    void setDestiny(System *destiny);

    bool operator==(const Flow &obj) const;
    bool operator!=(const Flow &obj) const;
    Flow &operator= (const Flow &obj);

    virtual float execute() = 0;
};

#endif
#include "flowLogistic.hpp"

FlowLogistic::FlowLogistic(){
    name = "NULL";
    origin = NULL;
    destiny = NULL;
}

FlowLogistic::FlowLogistic(Flow &obj){
    if(&obj == this)
        return;

    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
};

FlowLogistic::FlowLogistic(const string name, System *origin, System *destiny):Flow(name, origin, destiny){};
FlowLogistic::~FlowLogistic(){}

float FlowLogistic::execute(){
    return ((0.01 * getDestiny()->getValue()) * (1 - getDestiny()->getValue() / 70));
};  
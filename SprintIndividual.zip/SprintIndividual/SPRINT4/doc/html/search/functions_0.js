var searchData=
[
  ['add_132',['add',['../class_model.html#a70362afdd9db6268b4adaedfeddb2935',1,'Model::add(System *)=0'],['../class_model.html#ac1e19f5fcc4ced9defbfe2847a26ff33',1,'Model::add(Flow *)=0'],['../class_model_imp.html#a6e876c344a0f6fc6cbbba2239b07f40d',1,'ModelImp::add(System *)'],['../class_model_imp.html#a38ec23fbe8b4fe1e37e6b8a6e229b5a7',1,'ModelImp::add(Flow *)']]]
];

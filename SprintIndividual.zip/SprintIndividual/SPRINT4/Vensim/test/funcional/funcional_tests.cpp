#include "funcional_tests.hpp"

void exponentialFuncionalTest(){

    Model* model = new ModelImp();
    System* system1 = new SystemImp("pop1", 100.0);
    System* system2 = new SystemImp("pop2", 0.0);
    Flow* flow = new FlowExponentialImp("Exponencial", system1, system2);
    
    model->setName("Sistema exponencial");
    model->add(system1);
    model->add(system2);
    model->add(flow);

    model->run(0, 99, 1);

    model->show();

    assert(fabs(system1->getValue() - 36.6032) < 0.0001);
    assert(fabs(system2->getValue() - 63.3968) < 0.0001);

    model->clear();

    delete model;
    delete system1;
    delete system2;
    delete flow;
}

void logisticalFuncionalTest(){

    Model* model = new ModelImp();
    System* system1 = new SystemImp("p1", 100.0);
    System* system2 = new SystemImp("p2", 10.0);
    Flow* flow = new FlowLogisticImp("Logistic", system1, system2);
    
    model->setName("Sistema logistic");

    model->add(system1);
    model->add(system2);
    model->add(flow);

    model->run(0, 99, 1);

    model->show();

    assert(fabs(system1->getValue() - 88.2167) < 0.0001);
    assert(fabs(system2->getValue() - 21.7833) < 0.0001);

    model->clear();

    delete model;
    delete system1;
    delete system2;
    delete flow;
}

void complexFuncionalTest(){

    Model* model = new ModelImp();
    System* q1 = new SystemImp("q1", 100.0);
    System* q2 = new SystemImp("q2", 0.0);
    System* q3 = new SystemImp("q3", 100.0);
    System* q4 = new SystemImp("q4", 0.0);
    System* q5 = new SystemImp("q5", 0.0);
    Flow* f = new FlowExponentialImp("f", q1, q2);
    Flow* t = new FlowExponentialImp("f", q2, q3);
    Flow* u = new FlowExponentialImp("f", q3, q4);
    Flow* v = new FlowExponentialImp("f", q4, q1);
    Flow* g = new FlowExponentialImp("f", q1, q3);
    Flow* r = new FlowExponentialImp("f", q2, q5);
    
    model->setName("Sistema completo");

    model->add(q1);
    model->add(q2);
    model->add(q3);
    model->add(q4);
    model->add(q5);
    model->add(f);
    model->add(t);
    model->add(u);
    model->add(v);
    model->add(g);
    model->add(r);

    model->run(0, 99, 1);
    model->show();

    assert(fabs(q1->getValue() - 31.8513) < 0.0001);
    assert(fabs(q2->getValue() - 18.4003) < 0.0001);
    assert(fabs(q3->getValue() - 77.1143) < 0.0001);
    assert(fabs(q4->getValue() - 56.1728) < 0.0001);
    assert(fabs(q5->getValue() - 16.4612) < 0.0001);

    model->clear();

    delete model;
    delete q1;
    delete q2;
    delete q3;
    delete q4;
    delete q5;
    delete f;
    delete t;
    delete u;
    delete v;
    delete g;
    delete r;
}
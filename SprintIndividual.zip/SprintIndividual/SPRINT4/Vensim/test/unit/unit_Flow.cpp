#include "unit_Flow.hpp"

void unit_Flow_constructor(){
    System* system1 = new SystemImp();
    System* system2 = new SystemImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp();
    assert(flowExp1->getName() == "NULL");
    assert(flowExp1->getOrigin() == NULL);
    assert(flowExp1->getDestiny() == NULL);

    Flow* flowExp2 = new FlowExponentialImp("teste", system1, system2);
    assert(flowExp2->getName() == "teste");
    assert(flowExp2->getOrigin() == system1);
    assert(flowExp2->getDestiny() == system2);

    Flow* flowExp3 = new FlowExponentialImp(*flowExp2);


    // logistic
    Flow* flowLogist1 = new FlowLogisticImp();
    assert(flowLogist1->getName() == "NULL");
    assert(flowLogist1->getOrigin() == NULL);
    assert(flowLogist1->getDestiny() == NULL);

    Flow* flowLogist2 = new FlowLogisticImp("teste", system1, system2);
    assert(flowLogist2->getName() == "teste");
    assert(flowLogist2->getOrigin() == system1);
    assert(flowLogist2->getDestiny() == system2);

    Flow* flowLogist3 = new FlowLogisticImp(*flowLogist2);


    delete system1;
    delete system2;
    delete flowExp1;
    delete flowExp2;
    delete flowExp3;
    delete flowLogist1;
    delete flowLogist2;
    delete flowLogist3;

};

void unit_Flow_destructor(){};

void unit_Flow_getName(){
    System* system1 = new SystemImp();
    System* system2 = new SystemImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp("teste", system1, system2);
    assert(flowExp1->getName() == "teste");

    // logistic
    Flow* flowLogist1 = new FlowLogisticImp("teste", system1, system2);
    assert(flowLogist1->getName() == "teste");

    delete system1;
    delete system2;
    delete flowExp1;
    delete flowLogist1;

}

void unit_Flow_setName(){
    // exponential
    Flow* flowExp1 = new FlowExponentialImp();
    flowExp1->setName("test");
    assert(flowExp1->getName() == "test");

    // logistic
    Flow* flowLogist1 = new FlowLogisticImp();
    flowLogist1->setName("test");
    assert(flowLogist1->getName() == "test"); 

    delete flowExp1;
    delete flowLogist1;

}

void unit_Flow_getOrigin(){
    System* system1 = new SystemImp();
    System* system2 = new SystemImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp("teste", system1, system2);
    assert(flowExp1->getOrigin() == system1);

    // logistic
    Flow* flowLogist1 = new FlowLogisticImp("teste", system1, system2);
    assert(flowLogist1->getOrigin() == system1);

    delete system1;
    delete system2;
    delete flowExp1;
    delete flowLogist1;

}

void unit_Flow_setOrigin(){
    System* system1 = new SystemImp();
    System* system2 = new SystemImp();
    System* system3 = new SystemImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp("teste", system1, system2);
    flowExp1->setOrigin(system3);
    assert(flowExp1->getOrigin() == system3);

    // logistic
    Flow* flowLogist1 = new FlowLogisticImp("teste", system1, system2);
    flowLogist1->setOrigin(system3);
    assert(flowLogist1->getOrigin() == system3);

    delete system1;
    delete system2;
    delete flowExp1;
    delete flowLogist1;

}

void unit_Flow_getDestiny(){
    System* system1 = new SystemImp();
    System* system2 = new SystemImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp("teste", system1, system2);
    assert(flowExp1->getDestiny() == system2);

    // logistic
    Flow* flowLogist1 = new FlowLogisticImp("teste", system1, system2);
    assert(flowLogist1->getDestiny() == system2);

    delete system1;
    delete system2;
    delete flowExp1;
    delete flowLogist1;

}

void unit_Flow_setDestiny(){
    System* system1 = new SystemImp();
    System* system2 = new SystemImp();
    System* system3 = new SystemImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp("teste", system1, system2);
    flowExp1->setDestiny(system3);
    assert(flowExp1->getDestiny() == system3);

    // logistic
    Flow* flowLogist1 = new FlowLogisticImp("teste", system1, system2);
    flowLogist1->setDestiny(system3);
    assert(flowLogist1->getDestiny() == system3);

    delete system1;
    delete system2;
    delete flowExp1;
    delete flowLogist1;

}




void unit_Flow_execute(){
    System* system1 = new SystemImp(100.0);
    System* system2 = new SystemImp(0.0);
    Model* model = new ModelImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp("teste", system1, system2);
    model->add(system1);
    model->add(system2);
    model->add(flowExp1);

    model->run(0, 99, 1);

    assert(abs(system1->getValue() - 36.6032) <  0.0001);
    assert(abs(system2->getValue() - 63.3968) <  0.0001);

    model->clear();

    // logistic
    system1->setValue(100.0);
    system2->setValue(10.0);
    Flow* flowLogist1 = new FlowLogisticImp("teste", system1, system2);
    model->add(system1);
    model->add(system2);
    model->add(flowLogist1);

    model->run(0, 99, 1);

    assert(abs(system1->getValue() - 88.2167) <  0.0001f);
    assert(abs(system2->getValue() - 21.7834) <  0.0001f);

    model->clear();

    delete system1;
    delete system2;
    delete flowExp1;
    delete flowLogist1;
    delete model;

}

void run_unit_test_Flow(){
    unit_Flow_constructor();
    unit_Flow_destructor();
    unit_Flow_getName();
    unit_Flow_setName();
    unit_Flow_getOrigin();
    unit_Flow_setOrigin();
    unit_Flow_getDestiny();
    unit_Flow_setDestiny();
    unit_Flow_execute();
}
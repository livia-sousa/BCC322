#ifndef UNITFLOW_HPP
#define UNITFLOW_HPP

#include <iostream>
#include <cmath>
#include <cstring>
#include <assert.h>
#include "../../src/flow.hpp"
#include "../../src/flowExponential.hpp"
#include "../../src/flowLogistic.hpp"
#include "../../src/systemImp.hpp"
#include "../../src/system.hpp"
#include "../../src/model.hpp"
#include "../../src/modelImp.hpp"

/**
*@brief This function run the unit test of the Flow
*/
void run_unit_test_Flow();
/**
*@brief This function does the unit test of the Constructor 
*/
void unit_Flow_constructor();
/**
*@brief This function does the unit test of the destructor 
*/
void unit_Flow_destructor();
/**
*@brief This function does the unit test of the Getname
*/
void unit_Flow_getName();
/**
*@brief This function does the unit test of the Setname
*/
void unit_Flow_setName();
/**
*@brief This function does the unit test of the getorigin
*/
void unit_Flow_getOrigin();
/**
*@brief This function does the unit test of the setorigin
*/
void unit_Flow_setOrigin();
/**
*@brief This function does the unit test of the getdestiny
*/
void unit_Flow_getDestiny();
/**
*@brief This function does the unit test of the Setdestiny
*/
void unit_Flow_setDestiny();

/**
*@brief This function does the unit test of the execute
*/
void unit_Flow_execute();

#endif
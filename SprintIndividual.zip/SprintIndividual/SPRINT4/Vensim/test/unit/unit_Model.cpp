#include "unit_Model.hpp"

void unit_Model_constructor(){
    Model* model1 = new ModelImp();
    assert(model1->getName() == "NULL");
    assert(model1->getFlowSize() == 0);
    assert(model1->getSystemSize() == 0);

    vector<Flow*> vectorFlow;
    Flow* flowExp1 = new FlowExponentialImp();
    vectorFlow.push_back(flowExp1);

    vector<System*> vectorSystem;
    System* system1 = new SystemImp();
    vectorSystem.push_back(system1);

    Model* model2 = new ModelImp("teste", vectorFlow, vectorSystem);
    assert(model2->getName() == "teste");
    assert(model2->getFlowSize() == 1);
    assert(model2->getSystemSize() == 1);

    delete model1;
    delete model2;
    delete flowExp1;
    delete system1;
    vectorFlow.clear();
    vectorSystem.clear();

};

void unit_Model_destructor(){};

void unit_Model_getName(){
    Model* model1 = new ModelImp();
    assert(model1->getName() == "NULL");

    delete model1;

}

void unit_Model_setName(){
    Model* model1 = new ModelImp();
    model1->setName("test");
    assert(model1->getName() == "test");

    delete model1;

}

void unit_Model_add(){
    Model* model1 = new ModelImp();
    System* system1 = new SystemImp("system1");
    System* system2 = new SystemImp("system2");    
    Flow* flowExp1 = new FlowExponentialImp("flowExp", system1, system2);

    model1->add(system1);
    model1->add(system2);

    assert(model1->getSystemSize() == 2);

    for(auto it = model1->getSystemBegin(); it != model1->getSystemEnd(); it++){
        if((*it)->getName() == system1->getName())
            assert((*it)->getName() == system1->getName());
    }

    model1->add(flowExp1);

    assert(model1->getFlowSize() == 1);

    for(auto it = model1->getFlowBegin(); it != model1->getFlowEnd(); it++){
        if((*it)->getName() == flowExp1->getName())
            assert((*it)->getName() == flowExp1->getName());
    }

    model1->clear();

    delete model1;
    delete system1;
    delete system2;
    delete flowExp1;

}

void unit_Model_remove(){
    Model* model1 = new ModelImp();
    System* system1 = new SystemImp("system1");

    model1->add(system1);

    assert(model1->getSystemSize() == 1);

    for(auto it = model1->getSystemBegin(); it != model1->getSystemEnd(); it++){
        if((*it)->getName() == system1->getName())
            assert((*it)->getName() == system1->getName());
    }

    model1->remove(system1);

    assert(model1->getSystemSize() == 0);

    model1->clear();

    delete model1;
    delete system1;

}
void unit_Model_clear(){
    Model* model1 = new ModelImp();
    System* system1 = new SystemImp("system1");
    System* system2 = new SystemImp("system2");    
    Flow* flowExp1 = new FlowExponentialImp("flowExp", system1, system2);

    model1->add(system1);
    model1->add(system2);
    assert(model1->getSystemSize() == 2);

    model1->add(flowExp1);
    assert(model1->getFlowSize() == 1);

    model1->clear();

    assert(model1->getSystemSize() == 0);
    assert(model1->getFlowSize() == 0);

    delete model1;
    delete system1;
    delete system2;
    delete flowExp1;

}

void unit_Model_run(){
    System* system1 = new SystemImp(100.0);
    System* system2 = new SystemImp(0.0);
    Model* model = new ModelImp();

    // exponential
    Flow* flowExp1 = new FlowExponentialImp("teste", system1, system2);
    model->add(system1);
    model->add(system2);
    model->add(flowExp1);

    model->run(0, 99, 1);

    assert(abs(system1->getValue() - 36.6032) <  0.0001f);
    assert(abs(system2->getValue() - 63.3968) <  0.0001f);

    model->clear();

    delete system1;
    delete system2;
    delete flowExp1;
    delete model;
}

void run_unit_test_Model(){
    unit_Model_constructor();
    unit_Model_destructor();
    unit_Model_getName();
    unit_Model_setName();
    unit_Model_add();
    unit_Model_remove();
    unit_Model_clear();
    unit_Model_run();
}
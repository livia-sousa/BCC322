#include "unit_Model.hpp"
#include "unit_Flow.hpp"
#include "unit_System.hpp"
#include "unit_test.hpp"

int main(){
    run_unit_tests_globals();
    return 0;
}
/// Arquivo unit_tests.h
#ifndef UNIT_TESTS
#define UNIT_TESTS

#include "unit_System.hpp"
#include "unit_Flow.hpp"
#include "unit_Model.hpp"
#include <assert.h>
/**
*@brief This function run all unit tests
*/
void run_unit_tests_globals();


#endif
/**
 * @file modelImp.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the simulation model
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef MODELIMP_HPP
#define MODELIMP_HPP
#include <cstring>
#include <ostream>
#include <vector>
#include "system.hpp"
#include "model.hpp"
/**
 * @brief This model class stores two vectors containing the flows and systems of this model and the name.
 * 
 */
class ModelImp:public Model{
protected:
    /**
     * @brief This attribute has the model name
     * 
     */
    string name;
    /**
     * @brief This variable stores an array of pointer-to-flow variables
     * 
     */
    vector<Flow*> flows;
    /**
     * @brief This variable stores an array of pointer-to-systems variables
     * 
     */
    vector<System*> systems;
    
private:
    /**
     * @brief this method is a copy constructor of model
     * 
     * @param  model to be copied 
     */
    ModelImp(Model& obj);
    /**
     * @brief  This method is overloading the '=' operator, "cloning" from one model to another
     * 
     * @param The model to be cloned must be passed 
     * 
     * @return A model is returned that is a clone of what was passed to the method, which was the model that called this function, the model to the left of the '='
     */
    ModelImp& operator=(const ModelImp& obj);

public:
    /**
     * @brief This constructor is the empty constructor of the class
     * 
     */
    ModelImp();
    /**
     * @brief Construct a Model name
     * 
     * @param name 
     */
    ModelImp(const string name);
    /**
     * @brief This constructor assigns name, source and destination to flow
     * 
     * @param must be passed to the constructor a string (name), array of pointer-to-flow variables and array of pointer-to-systems variables. 
     */
    ModelImp(const string name, vector<Flow*> &flows, vector<System*> &systems);
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~ModelImp();

    /**
     * @brief setting the flow vector type
     * 
     */
    typedef typename vector<Flow*>::iterator itFlow;
    /**
     * @brief setting the systems vector type
     * 
     */
    typedef typename vector<System*>::iterator itSystem;
    
    /**
     * @brief This method returns the name of a flow
     * 
     * @return A string containing the name is returned.
     */
    string getName() const;

    /**
     * @brief This method assigns the name to a string
     * 
     * @param a string must be passed to the method
     */
    void setName(const string name);

    /**
     * @brief This method returns the flow from the beginning
     * 
     * @return the flow from the beginning 
     */

    itFlow getFlowBegin();
    /**
     * @brief This method returns the flow of the end
     * 
     * @return the flow of the end
     */
    itFlow getFlowEnd();

    /**
     * @brief This method returns the size of the flow vector
     * 
     * @return the size of the flow vector
     */
    int getFlowSize();

    /**
     * @brief This method returns the system from the beginning
     * 
     * @return  the system from the beginning
     */
    itSystem getSystemBegin();

    /**
     * @brief This method returns the system of the end
     * 
     * @return the system of the end 
     */
    itSystem getSystemEnd();
    /**
     * @brief This method returns the size of the system vector
     * 
     * @return  the size of the system vector
     */
    int getSystemSize();    

    /**
     * @brief this method adds a system
     * 
     * @param a pointer to system must be passed.
     */
    void add(System*);
    /**
     * @brief this method adds a flow
     * 
     * @param a pointer to flow must be passed.
     */
    void add(Flow*);
    /**
     * @brief this method removes a system
     * 
     * @return true if object and item have the same memory addres
     * @return false if object and item do not have the same memory addres 
     */
    bool remove(System*);
    /**
     * @brief this method removes a flow
     * 
     * @return true if object and item have the same memory addres
     * @return false if object and item do not have the same memory addres
     */
    bool remove(Flow*);
    /**
     * @brief  this method is to clean the model.
     * 
     */
    void clear();
    /**
     * @brief this method is to show the model.
     * 
     */
    void show();


    /**
     * @brief  must be passed three integers start, finish and increment
     * 
     */
    void run(int, int, int);    

};

#endif
    

/**
 * @file flowExponentialImp.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the exponential simulation flow
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef FLOWEXPONENTIALIMP_HPP
#define FLOWEXPONENTIALIMP_HPP
#include "flowImp.hpp"
/**
 * @brief This Flow class connects two systems and through the entered equation transfers values ​​from one system to another
 * 
 */
class FlowExponentialImp:public FlowImp{
public:    
    /**
     * @brief This constructor is the empty constructor of the class
     * 
     */
    FlowExponentialImp();
    /**
     * @brief this method is a copy constructor
     * 
     * @param flow to be copied 
     */
    FlowExponentialImp(Flow &obj);
    /**
     * @brief This constructor assigns name and the systems
     * 
     * @param must be passed to the constructor a string (name) and systems. 
     */
    FlowExponentialImp(const string name, System *origin, System *destiny);
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~FlowExponentialImp();
    /**
     * @brief  this method will be responsible for the flow equation
     * 
     */
    virtual float execute();  
};
#endif
/**
 * @file system.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the simulation system
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef SYSTEM_HPP
#define SYSTEM_HPP

#include <string>
#include <ostream>

using namespace std;
/**
 * @brief The System Interface is the Interface that defines the methods to be implemented
 * 
 * @author Lívia Stéffanny de Sousa
 */

class System{
public:
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~System(){};
    /**
     * @brief  This method returns the name of a system.
     * 
     * @return A string containing the name is returned. 
     */
    virtual string getName() const = 0;
    /**
     * @brief  This method assigns the name to a string
     * 
     * @param  A string must be passed to the method 
     */
    virtual void setName(const string name) = 0;
    /**
     * @brief This method returns the value of a system.
     * 
     * @return  A float containing the value is returned.
     */
    virtual float getValue() const = 0;
    /**
     * @brief  This method assigns the value to a string
     * 
     * @param A float must be passed to the method
     */
    virtual void setValue(float value) = 0;

    /**
     * @brief This method is overloading the '==' operator comparing a system
     * 
     * @param  The system to be compared with the system that called the method is passed 
     * @return A system is returned that is a clone of what was passed to the method, which was the system that called this function, the system to the left of the '='
     */
    virtual System& operator= (const System& obj) = 0;

};

#endif
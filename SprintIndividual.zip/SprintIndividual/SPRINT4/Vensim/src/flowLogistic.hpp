/**
 * @file flowLogistic.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the logistic simulation flow
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef FLOWLOGISTICIMP_HPP
#define FLOWLOGISTICIMP_HPP
#include "flowImp.hpp"
/**
 * @brief This Flow class connects two systems and through the entered equation transfers values ​​from one system to another
 * 
 */
class FlowLogisticImp:public FlowImp{
public:    
    /**
     * @brief Construct a new Flow Logistic
     * 
     */
    FlowLogisticImp();
    /**
     * @briefthis method is a copy constructor
     * 
     * @param flow to be copied
     */
    FlowLogisticImp(Flow &obj);
    /**
     * @brief This constructor assigns name and the systems
     * 
     * @param  must be passed to the constructor a string (name) and systems. 
     */
    FlowLogisticImp(const string name, System *origin, System *destiny);
    /**
     * @brief  This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~FlowLogisticImp();
    /**
     * @brief this method will be responsible for the flow equation
     * 
     * @return float 
     */
    virtual float execute();
};
#endif
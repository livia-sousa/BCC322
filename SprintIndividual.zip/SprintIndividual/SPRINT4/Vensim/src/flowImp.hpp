/**
 * @file flowImp.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the simulation flow
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef FLOWIMP_HPP
#define FLOWIMP_HPP
#include <iostream>
#include <string>
#include "system.hpp"
#include "flow.hpp"

/**
 * @brief The Flow Interface is the Interface that defines the methods to be implemented
 * 
 */
class FlowImp:public Flow{
protected:
    /**
     * @brief used to name the flow
     * 
     */
    string name;
    /**
     * @brief used to assing a flow origin
     * 
     */
    System *origin;
    /**
     * @brief used to assing a flow destiny
     * 
     */
    System *destiny;

public:
    /**
     * @brief Construct a new Flow
     * 
     */
    FlowImp();
    /**
     * @brief Construct a new Flow object
     * 
     * @param obj 
     */
    FlowImp(Flow &obj);
    /**
     * @brief This constructor assigns name, source and destination to flow
     * 
     * @param name 
     * @param origin 
     * @param destiny 
     */
    FlowImp(const string name, System *origin, System *destiny);
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~FlowImp();

    /**
     * @brief This method returns the name of a flow
     * 
     * @return the name of a flow 
     */
    string getName() const;
    /**
     * @brief This method assigns the name to a string
     * 
     * @param the name to a string
     */
    void setName(const string name);
    /**
     * @brief This method returns the Source System of a Flow
     * 
     * @return A System pointer of the origin is returned 
     */
    System *getOrigin() const;
    /**
     * @brief This method assigns an origin to the Flow
     * 
     * @param  The System pointer to be assigned must be passed.
     */
    void setOrigin(System *origin);
    /**
     * @brief This method returns the target System of a Flow
     * 
     * @return  the target System of a Flow 
     */
    System *getDestiny() const;
    /**
     * @brief This method assigns a destination to the Flow
     * 
     * @param The System pointer to be assigned must be passed 
     */
    void setDestiny(System *destiny);

    /**
     * @brief This method is overloading the '=' operator, "cloning" from one flow to another
    *
    *@param The flow to be cloned must be passed
     * @return A flow is returned that is a clone of what was passed to the method, which was the flow that called this function, the flow to the left of the '='
     */
    Flow &operator= (const Flow &obj);
    /**
     * @brief Pure virtual method that will be inherited by subclasses
    created by the user, this one will contain an equation that will be executed in the flow by the model.
     * 
     * @return float 
     */
    virtual float execute() = 0;
};

#endif
/**
 * @file model.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the simulation model
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef MODEL_HPP
#define MODEL_HPP
#include <cstring>
#include <ostream>
#include <vector>
#include "flow.hpp"
#include "flowExponential.hpp"
#include "flowLogistic.hpp"
#include "system.hpp"
#include "systemImp.hpp"


using namespace std;
/**
 * @brief This class represents the general simulation model, it contains figures for simulation and its execution.
 * 
 */
class Model{
private:
    /**
     * @brief  This method is overloading the '=' operator, "cloning" from one model to another
     * 
     * @param The model to be cloned must be passed 
     * 
     * @return A model is returned that is a clone of what was passed to the method, which was the model that called this function, the model to the left of the '='
     */

public:
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~Model() {};

    /**
     * @brief setting the flow vector type
     * 
     */
    typedef typename vector<Flow*>::iterator itFlow;
    /**
     * @brief setting the systems vector type
     * 
     */
    typedef typename vector<System*>::iterator itSystem;
    
    /**
     * @brief This method returns the name of a flow
     * 
     * @return A string containing the name is returned.
     */
    virtual string getName() const = 0;

    /**
     * @brief This method assigns the name to a string
     * 
     * @param a string must be passed to the method
     */
    virtual void setName(const string name) = 0;

    /**
     * @brief This method returns the flow from the beginning
     * 
     * @return the itflow type is returned
     */

    virtual itFlow getFlowBegin() = 0;
    /**
     * @brief This method returns the flow of the end
     * 
     * @return the itflow type is returned
     */
    virtual itFlow getFlowEnd() = 0;

    /**
     * @brief This method returns the size of the flow vector
     * 
     * @return an integer that is the size
     */
    virtual int getFlowSize() = 0;

    /**
     * @brief This method returns the system from the beginning
     * 
     * @return  the itsystem type is returned
     */
    virtual itSystem getSystemBegin() = 0;

    /**
     * @brief This method returns the system of the end
     * 
     * @return the itsystem type is returned 
     */
    virtual itSystem getSystemEnd() = 0;
    /**
     * @brief This method returns the size of the system vector
     * 
     * @return an integer that is the size
     */
    virtual int getSystemSize() = 0;    

    /**
     * @brief this method adds a system
     * 
     * @param a pointer to system must be passed.
     */
    virtual void add(System*) = 0;
    /**
     * @brief this method adds a flow
     * 
     * @param a pointer to flow must be passed.
     */
    virtual void add(Flow*) = 0;
    /**
     * @brief this method removes a system
     * 
     * @return true if object and item have the same memory addres
     * @return false if object and item do not have the same memory addres 
     */
    virtual bool remove(System*) = 0;
    /**
     * @brief this method removes a flow
     * 
     * @return true if object and item have the same memory addres
     * @return false if object and item do not have the same memory addres
     */
    virtual bool remove(Flow*) = 0;
    /**
     * @brief  this method is to clean the model.
     * 
     */
    virtual void clear() = 0;
    /**
     * @brief this method is to show the model.
     * 
     */
    virtual void show() = 0;


    /**
     * @brief this method is to run the model.
     * 
     * @param must be passed three integers start, finish and increment
     */
    virtual void run(int, int, int) = 0;    

};

#endif
    

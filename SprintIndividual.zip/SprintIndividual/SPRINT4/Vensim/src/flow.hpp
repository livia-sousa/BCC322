/**
 * @file flow.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the simulation flow
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef FLOW_HPP
#define FLOW_HPP
#include <iostream>
#include <string>
#include "system.hpp"

using namespace std;

/**
 * @brief The Flow Interface is the Interface that defines the methods to be implemented
 * 
 */
class Flow{
public:
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~Flow(){};

    /**
     * @brief This method returns the name of a flow
     * 
     * @return the name of a flow 
     */
    virtual string getName() const = 0;
    /**
     * @brief This method assigns the name to a string
     * 
     * @param A string must be passed to the method
     */
    virtual void setName(const string name) = 0;
    /**
     * @brief This method returns the Source System of a Flow
     * 
     * @return A System pointer of the origin is returned 
     */
    virtual System *getOrigin() const = 0;
    /**
     * @brief This method assigns an origin to the Flow
     * 
     * @param  The System pointer to be assigned must be passed.
     */
    virtual void setOrigin(System *origin) = 0;
    /**
     * @brief This method returns the target System of a Flow
     * 
     * @return  A System pointer is returned
     */
    virtual System *getDestiny() const = 0;
    /**
     * @brief This method assigns a destination to the Flow
     * 
     * @param The System pointer to be assigned must be passed 
     */
    virtual void setDestiny(System *destiny) = 0;

    /**
     * @brief This method is overloading the '=' operator, "cloning" from one flow to another
    *
    *@param The flow to be cloned must be passed
    * @return A flow is returned that is a clone of what was passed to the method, which was the flow that called this function, the flow to the left of the '='
    */
    virtual Flow &operator= (const Flow &obj) = 0;
    /**
     * @brief Pure virtual method that will be inherited by subclasses
    created by the user, this one will contain an equation that will be executed in the flow by the model.
     * 
     * @return float 
     */
    virtual float execute() = 0;
};

#endif
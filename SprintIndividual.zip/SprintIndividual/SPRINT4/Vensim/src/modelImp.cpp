#include "modelImp.hpp"
#include "flowExponential.hpp"
#include "flowLogistic.hpp"

ModelImp::ModelImp(){
    name = "NULL";
    flows.clear();
    systems.clear();
}

ModelImp::ModelImp(const string name, vector<Flow*> &flows, vector<System*> &systems) : name(name), flows(flows), systems(systems) {}
ModelImp::ModelImp(const string name):name(name){}

ModelImp::ModelImp(Model &obj){
    if(&obj == this)
        return;

    name = obj.getName();
}

ModelImp::~ModelImp(){}

string ModelImp::getName() const{
    return name;
}

void ModelImp::setName(const string name){
    this->name = name;
}

ModelImp::itFlow ModelImp::getFlowBegin(){
    return flows.begin();
}

ModelImp::itFlow ModelImp::getFlowEnd(){
    return flows.end();
}
    
int ModelImp::getFlowSize(){
    return flows.size();
}   

ModelImp::itSystem ModelImp::getSystemBegin() {
    return systems.begin();
}

ModelImp::itSystem ModelImp::getSystemEnd() {
    return systems.end();
}

int ModelImp::getSystemSize(){
    return systems.size();
} 

void ModelImp::add(System* subSystem){
    systems.push_back(subSystem);
}

void ModelImp::add(Flow* flow){
    flows.push_back(flow);
}

bool ModelImp::remove(System* obj){
    for(auto thisystem = systems.begin(); thisystem != systems.end(); thisystem++){
        if(*thisystem == obj){
            systems.erase(thisystem);
            return true;
        }
    }
    return false;
}

bool ModelImp::remove(Flow* obj){
    for(auto thisFlows = flows.begin(); thisFlows != flows.end(); thisFlows++){
        if(*thisFlows == obj){
            flows.erase(thisFlows);
            return true;
        }
    }
    return false;
}

ModelImp& ModelImp::operator=(const ModelImp& obj){
    if(this != &obj){
        this->flows.clear();
        this->systems.clear();
        this->flows.insert(this->flows.begin(), obj.flows.begin(), obj.flows.end());
        this->systems.insert(this->systems.begin(), obj.systems.begin(), obj.systems.end());
    }
    return *this;

}

void ModelImp::clear(){
    name = "NULL";
    flows.clear();
    systems.clear();
}

void ModelImp::run(int start, int finish, int increment){

    vector<Flow*>::iterator ItFlow;

    System* origin;
    System* destiny;

    vector<float> flowValue;

    int i = 0;
    int j = 0;
    float initial = 0.0;

    for (int i = 0; i < flows.size(); i++){
        flowValue.push_back(initial);
    }

    for(int index = start; index <= finish; index+=increment){
        i = 0;
        ItFlow = flows.begin();
        while (i != flows.size()){
            flowValue[i] = (*ItFlow)->execute();
            ItFlow++;
            i++;
        }
        j = 0;
        while (j != flows.size()){
            origin = flows[j]->getOrigin();
            origin->setValue(origin->getValue() - flowValue[j]);

            destiny = flows[j]->getDestiny();
            destiny->setValue(destiny->getValue() + flowValue[j]);
            j++;
        }
    }
    
}

void ModelImp::show(){
    cout<<endl;
    cout<<"Sub sistemas e seus valores:"<<endl;
    for(auto system : systems){
        cout<<"."<<system->getName()<<" "<<system->getValue()<<endl;
    }
    cout<<endl;
}
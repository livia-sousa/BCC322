#include "flowLogistic.hpp"

FlowLogisticImp::FlowLogisticImp(){
    name = "NULL";
    origin = NULL;
    destiny = NULL;
}

FlowLogisticImp::FlowLogisticImp(Flow &obj){
    if(&obj == this)
        return;

    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
};

FlowLogisticImp::FlowLogisticImp(const string name, System *origin, System *destiny):FlowImp(name, origin, destiny){};
FlowLogisticImp::~FlowLogisticImp(){}

float FlowLogisticImp::execute(){
    return ((0.01 * getDestiny()->getValue()) * (1 - getDestiny()->getValue() / 70));
};  
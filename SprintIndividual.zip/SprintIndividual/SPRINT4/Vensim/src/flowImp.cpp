#include "flowImp.hpp"

FlowImp::FlowImp(){
    name = "NULL";
    origin = NULL;
    destiny = NULL;
}

FlowImp::FlowImp(Flow &obj){
    if(&obj == this)
        return;

    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
}

FlowImp::FlowImp(const string name, System *origin, System *destiny):name(name), origin(origin), destiny(destiny){};
FlowImp::~FlowImp(){};

string FlowImp::getName() const{
    return name;
}

void FlowImp::setName(const string name){
    this->name = name;
}

System *FlowImp::getOrigin() const{
    return origin;
}

void FlowImp::setOrigin(System *origin){
    this->origin = origin;
}

System *FlowImp::getDestiny() const{
    return destiny;
}

void FlowImp::setDestiny(System *destiny){
    this->destiny = destiny;
}

Flow &FlowImp::operator = (const Flow &obj){
    if(&obj == this)
        return *this;

    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
    
    return *this;
}
#include "flowExponential.hpp"

FlowExponentialImp::FlowExponentialImp(){
    name = "NULL";
    origin = NULL;
    destiny = NULL;
}

FlowExponentialImp::FlowExponentialImp(Flow &obj){
    if(&obj == this)
        return;
    
    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
};

FlowExponentialImp::FlowExponentialImp(const string name, System *origin, System *destiny):FlowImp(name, origin, destiny){};
FlowExponentialImp::~FlowExponentialImp(){}

float FlowExponentialImp::execute(){
    return getOrigin()->getValue() * 0.01;
};
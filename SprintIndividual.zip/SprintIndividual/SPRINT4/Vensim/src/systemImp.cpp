#include "systemImp.hpp"

SystemImp::SystemImp(){
    name = "NULL";
    value = 0;
}

SystemImp::SystemImp(System &obj){
    if(&obj == this) 
        return;

    name = obj.getName();
    value = obj.getValue();
};

SystemImp::SystemImp(const string name, float value):name(name), value(value){}
SystemImp::SystemImp(const string name):name(name){}
SystemImp::SystemImp(float value):value(value){}
SystemImp::~SystemImp(){}

string SystemImp::getName() const{
    return name;
};

void SystemImp::setName(const string name){
    this->name = name;
}

float SystemImp::getValue() const{
    return value;
}

void SystemImp::setValue(float value){
    this->value = value;
}

System& SystemImp::operator= (const System& obj){
    if(&obj == this)
        return *this;
    
    name = obj.getName();
    value = obj.getValue();

    return *this;

}
/**
 * @file flowLogistic.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the logistic simulation flow
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef FLOWLOGISTIC_HPP
#define FLOWLOGISTIC_HPP

#include "flow.hpp"
/**
 * @brief This Flow class connects two systems and through the entered equation transfers values ​​from one system to another
 * 
 */
class FlowLogistic:public Flow{
public:    
    /**
     * @brief Construct a new Flow Logistic
     * 
     */
    FlowLogistic();
    /**
     * @brief Construct a new Flow Logistic object
     * 
     * @param obj 
     */
    FlowLogistic(Flow &obj);
    /**
     * @brief Construct a new Flow Logistic
     * 
     * @param name 
     * @param origin 
     * @param destiny 
     */
    FlowLogistic(const string name, System *origin, System *destiny);
    /**
     * @brief Destroy the Flow Logistic object
     * 
     */
    virtual ~FlowLogistic();
    /**
     * @brief Pure virtual method that will contain an equation that will be executed in the flow by the model.
     * 
     * @return float 
     */
    virtual float execute();
};
#endif
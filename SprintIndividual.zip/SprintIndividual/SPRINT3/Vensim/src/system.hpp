/**
 * @file system.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the simulation system
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef SYSTEM_HPP
#define SYSTEM_HPP

#include <string>
#include <ostream>

using namespace std;
/**
 * @brief The System Interface is the Interface that defines the methods to be implemented
 * 
 * @author Lívia Stéffanny de Sousa
 */

class System{
protected:
    /**
     * @brief This attribute has the system name
     * 
     */
    string name;
    /**
     * @brief This attribute has the system value
     * 
     */
    float value;

public:
    /**
     * @brief Construct a new System object
     * 
     */
    System();

    /**
     * @brief Construct a new System name
     * 
     * @param name 
     */
    System(const string name);
    /**
     * @brief Construct a new System value
     * 
     * @param value 
     */
    System(float value);
    /**
     * @brief Construct a new System object
     * 
     * @param obj 
     */
    System(System& obj);
    /**
     * @brief Construct a new System object
     * 
     * @param name 
     * @param value 
     */
    System(const string name, float value);
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~System();
    /**
     * @brief  This method returns the name of a system.
     * 
     * @return A string containing the name is returned. 
     */
    string getName() const;
    /**
     * @brief  This method assigns the name to a string
     * 
     * @param  A string must be passed to the method 
     */
    void setName(const string name);
    /**
     * @brief This method returns the value of a system.
     * 
     * @return  A float containing the value is returned.
     */
    float getValue() const;
    /**
     * @brief  This method assigns the value to a string
     * 
     * @param A float must be passed to the method
     */
    void setValue(float value);

    /**
     * @brief This method is overloading the '==' operator comparing a system
     * 
     * @param  The system to be compared with the system that called the method is passed 
     * @return System& obj
     */
    System& operator= (const System& obj);

};

#endif
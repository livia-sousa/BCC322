/**
 * @file model.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the simulation model
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef MODEL_HPP
#define MODEL_HPP
#include <cstring>
#include <ostream>
#include <vector>
#include "flow.hpp"
#include "flowExponential.hpp"
#include "flowLogistic.hpp"
#include "system.hpp"
/**
 * @brief This class represents the general simulation model, it contains figures for simulation and its execution.
 * 
 */
class Model{
protected:
    /**
     * @brief This attribute has the model name
     * 
     */
    string name;
    /**
     * @brief This attribute has the simulation flows
     * 
     */
    vector<Flow*> flows;
    /**
     * @brief This attribute has the simulation systems
     * 
     */
    vector<System*> systems;
    
private:
    /**
     * @brief Construct a new Model object
     * 
     * @param obj 
     */
    Model(Model& obj);
    /**
     * @brief  This method is overloading the '=' operator, "cloning" from one model to another
     * 
     * @param The model to be cloned must be passed 
     * 
     * @return A model is returned that is a clone of what was passed to the method, which was the model that called this function, the model to the left of the '='
     */
    Model& operator=(const Model& obj);

public:
    /**
     * @brief Construct a new Model
     * 
     */
    Model();
    /**
     * @brief Construct a new Model name
     * 
     * @param name 
     */
    Model(const string name);
    /**
     * @brief Construct a new Model
     * 
     * @param name 
     * @param flows 
     * @param systems 
     */
    Model(const string name, vector<Flow*> &flows, vector<System*> &systems);
    /**
     * @brief This destructor is a virtual destructor of the Class
     * 
     */
    virtual ~Model();

    /**
     * @brief setting the flow vector type
     * 
     */
    typedef typename vector<Flow*>::iterator itFlow;
    /**
     * @brief setting the systems vector type
     * 
     */
    typedef typename vector<System*>::iterator itSystem;
    
    /**
     * @brief This method returns the name of a flow
     * 
     * @return A string containing the name is returned.
     */
    string getName() const;

    /**
     * @brief This method assigns the name to a string
     * 
     * @param a string must be passed to the method
     */
    void setName(const string name);

    /**
     * @brief This method returns the flow from the beginning
     * 
     * @return the flow from the beginning 
     */

    itFlow getFlowBegin();
    /**
     * @brief This method returns the flow of the end
     * 
     * @return the flow of the end
     */
    itFlow getFlowEnd();

    /**
     * @brief This method returns the size of the flow vector
     * 
     * @return the size of the flow vector
     */
    int getFlowSize();

    /**
     * @brief This method returns the system from the beginning
     * 
     * @return  the system from the beginning
     */
    itSystem getSystemBegin();

    /**
     * @brief This method returns the system of the end
     * 
     * @return the system of the end 
     */
    itSystem getSystemEnd();
    /**
     * @brief This method returns the size of the system vector
     * 
     * @return  the size of the system vector
     */
    int getSystemSize();    

    /**
     * @brief this method adds a system
     * 
     */
         
    void add(System*);
    /**
     * @brief this method adds a flow
     * 
     */
    void add(Flow*);
    /**
     * @brief this method removes a system
     * 
     * @return true if object and item have the same memory addres
     * @return false if object and item do not have the same memory addres 
     */
    bool remove(System*);
    /**
     * @brief this method removes a flow
     * 
     * @return true if object and item have the same memory addres
     * @return false if object and item do not have the same memory addres
     */
    bool remove(Flow*);
    /**
     * @brief  this method is to clean the model.
     * 
     */
    void clear();
    /**
     * @brief this method is to show the model.
     * 
     */
    void show();


    /**
     * @brief this method is to run the model.
     * 
     */
    void run(int, int, int);    

};

#endif
    

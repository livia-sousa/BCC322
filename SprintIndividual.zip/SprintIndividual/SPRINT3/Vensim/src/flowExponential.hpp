/**
 * @file flowExponential.hpp
 * @author Lívia Stéffanny de Sousa
 * @brief This file represents the exponential simulation flow
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#define FLOWEXPONENTIAL_HPP
#include "flow.hpp"
/**
 * @brief This Flow class connects two systems and through the entered equation transfers values ​​from one system to another
 * 
 */
class FlowExponential:public Flow{
public:    
    /**
     * @brief Construct a new Flow Exponential
     * 
     */
    FlowExponential();
    /**
     * @brief Construct a new Flow Exponential object
     * 
     * @param obj 
     */
    FlowExponential(Flow &obj);
    /**
     * @brief Construct a new Flow Exponential o
     * 
     * @param name 
     * @param origin 
     * @param destiny 
     */
    FlowExponential(const string name, System *origin, System *destiny);
    /**
     * @brief Destroy the Flow Exponential
     * 
     */
    virtual ~FlowExponential();
    /**
     * @brief Pure virtual method that will contain an equation that will be executed in the flow by the model.
     * 
     * @return float 
     */
    virtual float execute();  
};
#endif
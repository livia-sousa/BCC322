#include "flow.hpp"

Flow::Flow(){
    name = "NULL";
    origin = NULL;
    destiny = NULL;
}

Flow::Flow(Flow &obj){
    if(&obj == this)
        return;

    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
}

Flow::Flow(const string name, System *origin, System *destiny):name(name), origin(origin), destiny(destiny){};
Flow::~Flow(){};

string Flow::getName() const{
    return name;
}

void Flow::setName(const string name){
    this->name = name;
}

System *Flow::getOrigin() const{
    return origin;
}

void Flow::setOrigin(System *origin){
    this->origin = origin;
}

System *Flow::getDestiny() const{
    return destiny;
}

void Flow::setDestiny(System *destiny){
    this->destiny = destiny;
}

Flow &Flow::operator = (const Flow &obj){
    if(&obj == this)
        return *this;

    name = obj.getName();
    origin = obj.getOrigin();
    destiny = obj.getDestiny();
    
    return *this;
}
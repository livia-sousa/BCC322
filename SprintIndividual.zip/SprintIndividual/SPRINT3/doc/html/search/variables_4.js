var searchData=
[
  ['systems_115',['systems',['../class_model.html#ac7dea8829149e597d2671dbc0a538bf7',1,'Model']]]
];

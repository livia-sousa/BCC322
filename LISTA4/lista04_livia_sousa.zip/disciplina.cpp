#include "disciplina.hpp"

Disciplina::Disciplina(string nome, long cod): nome(nome), cod(cod) {}

Disciplina::~Disciplina(){};

void Disciplina::setNome(string nome){
    this->nome = nome;
}

void Disciplina::setCod(long cod){
    this->cod = cod; 
}

string Disciplina::getNome(){
    return this->nome;
}
   
long Disciplina::getCod(){
    return this->cod;
}

void Disciplina::toString(){
    cout<<nome<<" - "<<cod<<endl;
}
#include<iostream>
#include<cstring>
#include<vector>
#include<assert.h>
using namespace std;

#ifndef naoOrdenado_hpp
#define naoOrdenado_hpp

template <class T>

class NaoOrdenado
{
    vector<pair<long, T>> vetor;
   
public:
    typedef typename vector<pair<long, T>>::iterator it;
    
    NaoOrdenado(void){};
    virtual ~NaoOrdenado(){};

    void insert(const long &key, T& obj){
        assert(&key || &obj != NULL);
        vetor.push_back(pair<long, T>(key, obj));
    }
    
    void print(void){
        typename vector <pair<long, T>>::iterator iter;
        for (iter = vetor.begin(); iter != vetor.end(); ++iter)
        {
            iter->second.toString();
        }
    }

    const int count(){
        return vetor.size();
    }

    const float sum(){
        return vetor.size();
    }

    const float average(){
        return vetor.sum()/vetor.size;
    }

};

#endif
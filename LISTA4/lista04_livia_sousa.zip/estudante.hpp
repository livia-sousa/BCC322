#include <cstring>
#include <iostream>

using namespace std;

#ifndef estudante_hpp
#define estudante_hpp

class Estudante {

    string nome;  
    long matricula;

public:
    Estudante(string="", long matricula=0);

    virtual ~Estudante();

    void setNome(string);  
    void setMatricula(long);
    
    string getNome();
    long getMatricula();   

    void toString();
};


#endif
#include<iostream>
#include<cstring>

using namespace std;

#ifndef disciplina_hpp
#define disciplina_hpp

class Disciplina{    

    string nome;
    long cod;

public:
    Disciplina(string nome="", long cod=0);

    virtual ~Disciplina();

    void setNome(string);
    void setCod(long);
    
    string getNome();
    long getCod();

    void toString();
};

#endif
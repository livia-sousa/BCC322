#include<iostream>
#include<cstring>
#include<vector>
#include <bits/stdc++.h>
#include<assert.h>
using namespace std;

#ifndef ordenado_hpp
#define ordenado_hpp

template <class T>

class Ordenado
{
    vector<pair<long, T>> vetor;

public:
    typedef typename vector<pair<long, T>>::iterator it;
    
    Ordenado(void){};
    virtual ~Ordenado(){};

    void insert(const long &key, T& obj){
        assert(&key || &obj != NULL);
        vetor.push_back(pair<long, T>(key, obj));
    }

    void ordena(){
        sort(vetor.begin(), vetor.end(), [](pair<long, T>&a, pair<long, T>&b){
            return a.first < b.first;
        });
    }
    
    void print(void){
        typename vector <pair<long, T>>::iterator iter;
        for (iter = vetor.begin(); iter != vetor.end(); ++iter)
        {
            iter->second.toString();
        }
    }

    const int count(){
        return vetor.size();
    }

    const float sum(){
        return vetor.size();
    }

    const float average(){
        return vetor.sum()/vetor.size;
    }

};

#endif
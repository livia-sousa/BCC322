#include"estudante.hpp"
#include"disciplina.hpp"
#include"ordenado.hpp"
#include"naoOrdenado.hpp"

//Livia Steffanny de Sousa - 20.1.4029

int main(int argc, char* argv[]){

    // estudante nao ordenado
    cout<<"Estudantes nao ordenadas"<<endl;   

    NaoOrdenado<Estudante> naoOrdenadoAluno;

    Estudante aluno1 = Estudante("Maria", 17015587);
    naoOrdenadoAluno.insert(aluno1.getMatricula(), aluno1);
    Estudante aluno2 = Estudante("Gustavo", 17015889);
    naoOrdenadoAluno.insert(aluno2.getMatricula(), aluno2);    
    Estudante aluno3 = Estudante("ze", 17015821);
    naoOrdenadoAluno.insert(aluno3.getMatricula(), aluno3);
    naoOrdenadoAluno.print();

    cout<<endl;
    
    // disciplina nao ordenado
    cout<<"Disciplinas nao ordenados"<<endl;

    NaoOrdenado<Disciplina> naoOrdenadoDiscp;

    Disciplina discp1 = Disciplina("Introdução Ciencia", 100);
    naoOrdenadoDiscp.insert(discp1.getCod(), discp1);
    Disciplina discp2 = Disciplina("Programacao", 300);
    naoOrdenadoDiscp.insert(discp2.getCod(), discp2);
    Disciplina discp3 = Disciplina("Metodologia", 200);
    naoOrdenadoDiscp.insert(discp3.getCod(), discp3);    

    naoOrdenadoDiscp.print();

    cout<<endl;
    cout<<"-------------------------------"<<endl;
    cout<<endl;

    // estudante ordenado
    cout<<"Estudantes ordenados"<<endl;

    Ordenado<Estudante> ordenadoAluno;

    Estudante aluno4 = Estudante("Maria", 17015587);
    ordenadoAluno.insert(aluno4.getMatricula(), aluno4);
    Estudante aluno5 = Estudante("Gustavo", 17015889);
    ordenadoAluno.insert(aluno5.getMatricula(), aluno5);    
    Estudante aluno6 = Estudante("ze", 17015821);
    ordenadoAluno.insert(aluno6.getMatricula(), aluno6);

    ordenadoAluno.ordena();

    ordenadoAluno.print();

    cout<<endl;
    
    // disciplina nao ordenado
    cout<<"Disciplinas ordenadas"<<endl;

    Ordenado<Disciplina> ordenadoDiscp;

    Disciplina discp4 = Disciplina("Programacao", 300);
    ordenadoDiscp.insert(discp4.getCod(), discp4);
    Disciplina discp5 = Disciplina("Introdução Ciencia", 100);
    ordenadoDiscp.insert(discp5.getCod(), discp5);
    Disciplina discp6 = Disciplina("Metodologia", 200);
    ordenadoDiscp.insert(discp6.getCod(), discp6);
    

    ordenadoDiscp.ordena();
    
    ordenadoDiscp.print();

    cout<<endl;
    cout<<"-------------------------------"<<endl;
    cout<<endl;
  
    return 0;
}
#include "estudante.hpp"

Estudante::Estudante(string nome, long matricula): nome(nome), matricula(matricula) {}

Estudante::~Estudante(){};

void Estudante::setNome(string nome){
    this->nome = nome;
}  

void Estudante::setMatricula(long mat){
    this->matricula = mat;
} 

string Estudante::getNome(){
    return this->nome;
}
 
long Estudante::getMatricula(){
    return this->matricula;
}

void Estudante::toString(){
    cout<<nome<<" - "<<matricula<<endl;
}
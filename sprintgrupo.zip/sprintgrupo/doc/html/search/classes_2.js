var searchData=
[
  ['crudpixwindow_0',['crudPixWindow',['../classcrud_pix_window.html',1,'crudPixWindow'],['../class_ui_1_1crud_pix_window.html',1,'Ui::crudPixWindow']]]
];

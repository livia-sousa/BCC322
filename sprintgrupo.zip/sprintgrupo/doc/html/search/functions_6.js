var searchData=
[
  ['operator_3d_0',['operator=',['../class_pix.html#ae5d3f429be52bf534e2f50faf6282b40',1,'Pix']]]
];

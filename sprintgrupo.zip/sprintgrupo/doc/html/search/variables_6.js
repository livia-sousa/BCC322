var searchData=
[
  ['menubar_0',['menubar',['../class_ui__crud_pix_window.html#ad3d94195bc4fd15dfaf2309656d4684f',1,'Ui_crudPixWindow::menubar()'],['../class_ui___login_window.html#a5d3332cf7566b79fd1f29bcf12e560ec',1,'Ui_LoginWindow::menubar()'],['../class_ui___main_menu_window.html#af4540675a65ee9b5c42f6c7a084ced92',1,'Ui_MainMenuWindow::menubar()']]]
];

var searchData=
[
  ['testpix_0',['TestPix',['../class_test_pix.html#a6279bd3006e291b1a9eb5e258a9ba539',1,'TestPix::TestPix(QObject *parent=nullptr)'],['../class_test_pix.html#a13e5602f40b8adb10dd819397e43ffc5',1,'TestPix::TestPix()']]]
];

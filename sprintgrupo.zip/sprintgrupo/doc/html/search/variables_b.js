var searchData=
[
  ['tablewidget_0',['tableWidget',['../class_ui__crud_pix_window.html#afac393b805447ba44fb275f8f4429bd5',1,'Ui_crudPixWindow']]],
  ['tituloonghelper_1',['tituloONGHelper',['../class_ui__add_pix_window.html#a49c2431135f70608bea8254f03a103ee',1,'Ui_addPixWindow::tituloONGHelper()'],['../class_ui__edit_pix_window.html#a1e653d7fa63bc57fcf016d72c0462256',1,'Ui_editPixWindow::tituloONGHelper()'],['../class_ui___login_window.html#a98efe85ab26e2f8fdcfc2ca8c7e4e55b',1,'Ui_LoginWindow::tituloONGHelper()']]]
];

var searchData=
[
  ['editpixwindow_0',['editPixWindow',['../classedit_pix_window.html',1,'editPixWindow'],['../class_ui_1_1edit_pix_window.html',1,'Ui::editPixWindow']]]
];

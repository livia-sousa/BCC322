var searchData=
[
  ['mingw_5fhas_5fsecure_5fapi_0',['MINGW_HAS_SECURE_API',['../teste_u_i_2_teste_u_i_2build-_b_d_d_test_v2-_desktop___qt__6__2__4___min_g_w__64__bit-_debug_2_ba8f6bc9c551e0b57b1b754238de76cd1.html#a7652218632d79c675cce0c49732ee345',1,'moc_predefs.h']]]
];

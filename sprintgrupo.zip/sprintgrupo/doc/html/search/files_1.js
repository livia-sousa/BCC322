var searchData=
[
  ['addpixwindow_2ecpp_0',['addpixwindow.cpp',['../addpixwindow_8cpp.html',1,'']]],
  ['addpixwindow_2eh_1',['addpixwindow.h',['../addpixwindow_8h.html',1,'']]]
];

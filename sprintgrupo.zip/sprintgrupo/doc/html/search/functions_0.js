var searchData=
[
  ['addpixwindow_0',['addPixWindow',['../classadd_pix_window.html#a14669633d1da9844ae507cb10708e4a3',1,'addPixWindow']]]
];

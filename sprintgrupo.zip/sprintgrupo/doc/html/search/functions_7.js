var searchData=
[
  ['piximp_0',['PixImp',['../class_pix_imp.html#a2829980bc2da1a12cf8878a230d05f7a',1,'PixImp::PixImp()'],['../class_pix_imp.html#ad23c5133b669f5040e75094bf81ff3df',1,'PixImp::PixImp(QDateTime d, float v, QString n)']]]
];

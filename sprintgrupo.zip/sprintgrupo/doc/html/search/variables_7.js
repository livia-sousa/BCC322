var searchData=
[
  ['name_0',['name',['../class_pix_imp.html#a3d2e580fdd0e3574c1106370c23b0972',1,'PixImp']]],
  ['nametextedit_1',['nameTextEdit',['../class_ui__add_pix_window.html#a6568f0b1df7ebaafe56e3ce8b727f410',1,'Ui_addPixWindow::nameTextEdit()'],['../class_ui__edit_pix_window.html#ac2b0bbfcb8047d9b8d7bc68c4c906659',1,'Ui_editPixWindow::nameTextEdit()']]]
];

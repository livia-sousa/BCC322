var indexSectionsWithContent =
{
  0: "2_abcdeghilmnopqrstuvw~",
  1: "abcelmpqtu",
  2: "u",
  3: "2acelmptu",
  4: "aceglmoprst~",
  5: "bcdhilmnorstv",
  6: "s",
  7: "n",
  8: "b",
  9: "_acdhmpqsuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros"
};


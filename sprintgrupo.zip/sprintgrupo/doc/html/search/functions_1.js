var searchData=
[
  ['createpix_0',['createPix',['../class_pix_list.html#a491a800ec568dff4a5b9ea15ed4522f2',1,'PixList']]],
  ['crudpixwindow_1',['crudPixWindow',['../classcrud_pix_window.html#a4761ed1d21e2daf8e400443461950821',1,'crudPixWindow']]]
];

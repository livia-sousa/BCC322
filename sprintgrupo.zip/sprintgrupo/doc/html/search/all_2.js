var searchData=
[
  ['addpixwindow_0',['addPixWindow',['../classadd_pix_window.html',1,'addPixWindow'],['../classadd_pix_window.html#a14669633d1da9844ae507cb10708e4a3',1,'addPixWindow::addPixWindow()'],['../class_ui_1_1add_pix_window.html',1,'Ui::addPixWindow']]],
  ['addpixwindow_2ecpp_1',['addpixwindow.cpp',['../addpixwindow_8cpp.html',1,'']]],
  ['addpixwindow_2eh_2',['addpixwindow.h',['../addpixwindow_8h.html',1,'']]],
  ['architecture_5fid_3',['ARCHITECTURE_ID',['../_c_make_c_x_x_compiler_id_8cpp.html#aba35d0d200deaeb06aee95ca297acb28',1,'CMakeCXXCompilerId.cpp']]]
];

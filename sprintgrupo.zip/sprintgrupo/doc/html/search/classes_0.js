var searchData=
[
  ['addpixwindow_0',['addPixWindow',['../classadd_pix_window.html',1,'addPixWindow'],['../class_ui_1_1add_pix_window.html',1,'Ui::addPixWindow']]]
];

var searchData=
[
  ['removerbutton_0',['removerButton',['../class_ui__crud_pix_window.html#a6ca3fb45bb4b59fbdd7c42f0b095d341',1,'Ui_crudPixWindow']]]
];

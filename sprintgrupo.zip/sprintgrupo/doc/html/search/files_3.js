var searchData=
[
  ['editpixwindow_2ecpp_0',['editpixwindow.cpp',['../editpixwindow_8cpp.html',1,'']]],
  ['editpixwindow_2eh_1',['editpixwindow.h',['../editpixwindow_8h.html',1,'']]]
];

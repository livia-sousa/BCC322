var searchData=
[
  ['removerbutton_0',['removerButton',['../class_ui__crud_pix_window.html#a6ca3fb45bb4b59fbdd7c42f0b095d341',1,'Ui_crudPixWindow']]],
  ['retranslateui_1',['retranslateUi',['../class_ui__add_pix_window.html#a57a1701325361c54a3bc8207c812c041',1,'Ui_addPixWindow::retranslateUi()'],['../class_ui__crud_pix_window.html#a4fb46f5d559c9ceda14ab47177bfcb2c',1,'Ui_crudPixWindow::retranslateUi()'],['../class_ui__edit_pix_window.html#a5952c3ce00a0ef577c4e9e99b01dbb5d',1,'Ui_editPixWindow::retranslateUi()'],['../class_ui___login_window.html#ae6b60c1f325e1e259cdf4b294338699b',1,'Ui_LoginWindow::retranslateUi()'],['../class_ui___main_menu_window.html#a54760c64b517a4256ab8e1c5fc773201',1,'Ui_MainMenuWindow::retranslateUi()']]]
];

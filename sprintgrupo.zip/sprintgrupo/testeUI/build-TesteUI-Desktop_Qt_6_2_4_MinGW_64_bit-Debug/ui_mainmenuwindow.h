/********************************************************************************
** Form generated from reading UI file 'mainmenuwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINMENUWINDOW_H
#define UI_MAINMENUWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainMenuWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QPushButton *loginButton_3;
    QPushButton *crudButton;
    QPushButton *loginButton;
    QPushButton *sairButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainMenuWindow)
    {
        if (MainMenuWindow->objectName().isEmpty())
            MainMenuWindow->setObjectName(QString::fromUtf8("MainMenuWindow"));
        MainMenuWindow->resize(800, 600);
        centralwidget = new QWidget(MainMenuWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial")});
        font.setPointSize(12);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8(""));

        verticalLayout->addWidget(label);

        loginButton_3 = new QPushButton(centralwidget);
        loginButton_3->setObjectName(QString::fromUtf8("loginButton_3"));
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(loginButton_3->sizePolicy().hasHeightForWidth());
        loginButton_3->setSizePolicy(sizePolicy);
        loginButton_3->setMinimumSize(QSize(300, 100));
        loginButton_3->setSizeIncrement(QSize(15, 15));
        loginButton_3->setBaseSize(QSize(200, 200));

        verticalLayout->addWidget(loginButton_3);

        crudButton = new QPushButton(centralwidget);
        crudButton->setObjectName(QString::fromUtf8("crudButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(crudButton->sizePolicy().hasHeightForWidth());
        crudButton->setSizePolicy(sizePolicy1);
        crudButton->setMinimumSize(QSize(300, 100));
        crudButton->setSizeIncrement(QSize(15, 15));
        crudButton->setBaseSize(QSize(200, 200));

        verticalLayout->addWidget(crudButton);

        loginButton = new QPushButton(centralwidget);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));
        sizePolicy1.setHeightForWidth(loginButton->sizePolicy().hasHeightForWidth());
        loginButton->setSizePolicy(sizePolicy1);
        loginButton->setMinimumSize(QSize(300, 100));
        loginButton->setSizeIncrement(QSize(15, 15));
        loginButton->setBaseSize(QSize(200, 200));

        verticalLayout->addWidget(loginButton);

        sairButton = new QPushButton(centralwidget);
        sairButton->setObjectName(QString::fromUtf8("sairButton"));
        sairButton->setEnabled(true);
        sizePolicy1.setHeightForWidth(sairButton->sizePolicy().hasHeightForWidth());
        sairButton->setSizePolicy(sizePolicy1);
        sairButton->setMinimumSize(QSize(300, 100));
        sairButton->setBaseSize(QSize(50, 50));
        sairButton->setAutoFillBackground(false);
        sairButton->setFlat(false);

        verticalLayout->addWidget(sairButton);

        MainMenuWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainMenuWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        MainMenuWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainMenuWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainMenuWindow->setStatusBar(statusbar);

        retranslateUi(MainMenuWindow);
        QObject::connect(sairButton, &QPushButton::clicked, MainMenuWindow, qOverload<>(&QMainWindow::close));

        sairButton->setDefault(false);


        QMetaObject::connectSlotsByName(MainMenuWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainMenuWindow)
    {
        MainMenuWindow->setWindowTitle(QCoreApplication::translate("MainMenuWindow", "MainWindow", nullptr));
#if QT_CONFIG(tooltip)
        label->setToolTip(QCoreApplication::translate("MainMenuWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        label->setWhatsThis(QCoreApplication::translate("MainMenuWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        label->setText(QCoreApplication::translate("MainMenuWindow", "<html><head/><body><p align=\"center\">Menu</p></body></html>", nullptr));
        loginButton_3->setText(QCoreApplication::translate("MainMenuWindow", "Cadastrar Pix", nullptr));
        crudButton->setText(QCoreApplication::translate("MainMenuWindow", "Gerenciar Lista de Pix", nullptr));
        loginButton->setText(QCoreApplication::translate("MainMenuWindow", "Gerar Relat\303\263rio", nullptr));
        sairButton->setText(QCoreApplication::translate("MainMenuWindow", "Sair", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainMenuWindow: public Ui_MainMenuWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINMENUWINDOW_H

/********************************************************************************
** Form generated from reading UI file 'editpixwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITPIXWINDOW_H
#define UI_EDITPIXWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>

QT_BEGIN_NAMESPACE

class Ui_editPixWindow
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *tituloONGHelper;
    QPlainTextEdit *valueTextEdit;
    QPlainTextEdit *nameTextEdit;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *editPixWindow)
    {
        if (editPixWindow->objectName().isEmpty())
            editPixWindow->setObjectName(QString::fromUtf8("editPixWindow"));
        editPixWindow->resize(592, 367);
        buttonBox = new QDialogButtonBox(editPixWindow);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(360, 330, 221, 24));
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        tituloONGHelper = new QLabel(editPixWindow);
        tituloONGHelper->setObjectName(QString::fromUtf8("tituloONGHelper"));
        tituloONGHelper->setGeometry(QRect(30, 10, 521, 81));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(tituloONGHelper->sizePolicy().hasHeightForWidth());
        tituloONGHelper->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial")});
        font.setPointSize(28);
        tituloONGHelper->setFont(font);
        valueTextEdit = new QPlainTextEdit(editPixWindow);
        valueTextEdit->setObjectName(QString::fromUtf8("valueTextEdit"));
        valueTextEdit->setGeometry(QRect(170, 220, 261, 21));
        nameTextEdit = new QPlainTextEdit(editPixWindow);
        nameTextEdit->setObjectName(QString::fromUtf8("nameTextEdit"));
        nameTextEdit->setGeometry(QRect(170, 170, 261, 21));
        label = new QLabel(editPixWindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 160, 151, 41));
        label_2 = new QLabel(editPixWindow);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 210, 151, 41));

        retranslateUi(editPixWindow);

        QMetaObject::connectSlotsByName(editPixWindow);
    } // setupUi

    void retranslateUi(QDialog *editPixWindow)
    {
        editPixWindow->setWindowTitle(QCoreApplication::translate("editPixWindow", "Dialog", nullptr));
        tituloONGHelper->setText(QCoreApplication::translate("editPixWindow", "<html><head/><body><p align=\"center\">EDITAR PIX</p><p align=\"center\"><br/></p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("editPixWindow", "<html><head/><body><p align=\"right\"><span style=\" font-weight:700;\">NOME DO CLIENTE: </span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("editPixWindow", "<html><head/><body><p align=\"right\"><span style=\" font-weight:700;\">VALOR DO PIX: R$ </span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class editPixWindow: public Ui_editPixWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITPIXWINDOW_H

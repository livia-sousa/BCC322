/********************************************************************************
** Form generated from reading UI file 'crudpixwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CRUDPIXWINDOW_H
#define UI_CRUDPIXWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_crudPixWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QLabel *listaPixLabel;
    QTableWidget *tableWidget;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *removerButton;
    QPushButton *voltarButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *crudPixWindow)
    {
        if (crudPixWindow->objectName().isEmpty())
            crudPixWindow->setObjectName(QString::fromUtf8("crudPixWindow"));
        crudPixWindow->resize(800, 600);
        centralwidget = new QWidget(crudPixWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        listaPixLabel = new QLabel(centralwidget);
        listaPixLabel->setObjectName(QString::fromUtf8("listaPixLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(listaPixLabel->sizePolicy().hasHeightForWidth());
        listaPixLabel->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial")});
        font.setPointSize(28);
        listaPixLabel->setFont(font);

        verticalLayout->addWidget(listaPixLabel);

        tableWidget = new QTableWidget(centralwidget);
        if (tableWidget->columnCount() < 3)
            tableWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableWidget->setAlternatingRowColors(true);
        tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableWidget->horizontalHeader()->setMinimumSectionSize(150);

        verticalLayout->addWidget(tableWidget);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        removerButton = new QPushButton(centralwidget);
        removerButton->setObjectName(QString::fromUtf8("removerButton"));

        horizontalLayout_2->addWidget(removerButton);

        voltarButton = new QPushButton(centralwidget);
        voltarButton->setObjectName(QString::fromUtf8("voltarButton"));

        horizontalLayout_2->addWidget(voltarButton);


        verticalLayout->addLayout(horizontalLayout_2);

        crudPixWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(crudPixWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        crudPixWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(crudPixWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        crudPixWindow->setStatusBar(statusbar);

        retranslateUi(crudPixWindow);
        QObject::connect(voltarButton, &QPushButton::clicked, crudPixWindow, qOverload<>(&QMainWindow::close));

        QMetaObject::connectSlotsByName(crudPixWindow);
    } // setupUi

    void retranslateUi(QMainWindow *crudPixWindow)
    {
        crudPixWindow->setWindowTitle(QCoreApplication::translate("crudPixWindow", "MainWindow", nullptr));
        listaPixLabel->setText(QCoreApplication::translate("crudPixWindow", "<html><head/><body><p align=\"center\">Lista de Pix</p><p align=\"center\"><br/></p></body></html>", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("crudPixWindow", "Data", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("crudPixWindow", "Nome", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("crudPixWindow", "Valor", nullptr));
        removerButton->setText(QCoreApplication::translate("crudPixWindow", "Remover", nullptr));
        voltarButton->setText(QCoreApplication::translate("crudPixWindow", "Voltar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class crudPixWindow: public Ui_crudPixWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CRUDPIXWINDOW_H

/********************************************************************************
** Form generated from reading UI file 'addpixwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPIXWINDOW_H
#define UI_ADDPIXWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_addPixWindow
{
public:
    QPushButton *cadastrarButton;
    QPushButton *cancelarButton;
    QLabel *tituloONGHelper;
    QLabel *label;
    QLabel *label_2;
    QPlainTextEdit *valueTextEdit;
    QPlainTextEdit *nameTextEdit;

    void setupUi(QDialog *addPixWindow)
    {
        if (addPixWindow->objectName().isEmpty())
            addPixWindow->setObjectName(QString::fromUtf8("addPixWindow"));
        addPixWindow->resize(641, 539);
        cadastrarButton = new QPushButton(addPixWindow);
        cadastrarButton->setObjectName(QString::fromUtf8("cadastrarButton"));
        cadastrarButton->setGeometry(QRect(30, 430, 201, 61));
        cancelarButton = new QPushButton(addPixWindow);
        cancelarButton->setObjectName(QString::fromUtf8("cancelarButton"));
        cancelarButton->setGeometry(QRect(400, 430, 201, 61));
        tituloONGHelper = new QLabel(addPixWindow);
        tituloONGHelper->setObjectName(QString::fromUtf8("tituloONGHelper"));
        tituloONGHelper->setGeometry(QRect(60, 40, 521, 81));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(tituloONGHelper->sizePolicy().hasHeightForWidth());
        tituloONGHelper->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial")});
        font.setPointSize(28);
        tituloONGHelper->setFont(font);
        label = new QLabel(addPixWindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 190, 151, 41));
        label_2 = new QLabel(addPixWindow);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 240, 151, 41));
        valueTextEdit = new QPlainTextEdit(addPixWindow);
        valueTextEdit->setObjectName(QString::fromUtf8("valueTextEdit"));
        valueTextEdit->setGeometry(QRect(200, 250, 261, 21));
        nameTextEdit = new QPlainTextEdit(addPixWindow);
        nameTextEdit->setObjectName(QString::fromUtf8("nameTextEdit"));
        nameTextEdit->setGeometry(QRect(200, 200, 261, 21));

        retranslateUi(addPixWindow);
        QObject::connect(cancelarButton, &QPushButton::clicked, addPixWindow, qOverload<>(&QDialog::close));

        QMetaObject::connectSlotsByName(addPixWindow);
    } // setupUi

    void retranslateUi(QDialog *addPixWindow)
    {
        addPixWindow->setWindowTitle(QCoreApplication::translate("addPixWindow", "Dialog", nullptr));
        cadastrarButton->setText(QCoreApplication::translate("addPixWindow", "Cadastrar", nullptr));
        cancelarButton->setText(QCoreApplication::translate("addPixWindow", "Cancelar", nullptr));
        tituloONGHelper->setText(QCoreApplication::translate("addPixWindow", "<html><head/><body><p align=\"center\">CADASTRAR PIX</p><p align=\"center\"><br/></p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("addPixWindow", "<html><head/><body><p align=\"right\"><span style=\" font-weight:700;\">NOME DO CLIENTE: </span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("addPixWindow", "<html><head/><body><p align=\"right\"><span style=\" font-weight:700;\">VALOR DO PIX: R$ </span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class addPixWindow: public Ui_addPixWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPIXWINDOW_H

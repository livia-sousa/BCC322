#include "crudpixwindow.h"
#include "ui_crudpixwindow.h"
#include <iostream>
#include "../../TesteSimplesPix/pixlist.h"
#include <QMessageBox>

crudPixWindow::crudPixWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::crudPixWindow)
{
    ui->setupUi(this);
    QMainWindow::showFullScreen();
    for(auto itr = PixList::getInstance()->getList(); itr != PixList::getInstance()->getEndList(); ++itr){
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 0, new QTableWidgetItem((*itr)->getData().toString()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 1, new QTableWidgetItem((*itr)->getName()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 2, new QTableWidgetItem("R$" + QString::number((*itr)->getValue())));
    }
}

crudPixWindow::~crudPixWindow(){
    delete ui;
}




void crudPixWindow::on_tableWidget_cellDoubleClicked(int row, int column){
    epw = new editPixWindow(this, row);
    epw->setWindowModality(Qt::ApplicationModal);
    epw->show();
}


void crudPixWindow::on_removerButton_clicked()
{
    int i = ui->tableWidget->currentRow();
    auto itr = PixList::getInstance()->getList();
    while(i != 0){
        ++itr;
        i--;
    }
    if(QMessageBox::question(this, "REMOVER PIX", "Voce deseja remover esse Pix?", QMessageBox::Yes|QMessageBox::No) == QMessageBox::Yes){
        PixList::getInstance()->erase(itr);
        ui->tableWidget->removeRow(ui->tableWidget->currentRow());
        QMessageBox::information(this, "REMOVER PIX", "PIX REMOVIDO COM SUCESSO");
    }

}


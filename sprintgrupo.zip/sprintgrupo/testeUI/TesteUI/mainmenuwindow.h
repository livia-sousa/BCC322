#ifndef MAINMENUWINDOW_H
#define MAINMENUWINDOW_H

#include <QMainWindow>
#include "addpixwindow.h"
#include "crudpixwindow.h"

namespace Ui {
class MainMenuWindow;
}

class MainMenuWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainMenuWindow(QWidget *parent = nullptr);
    ~MainMenuWindow();

private slots:
    void on_loginButton_3_clicked();

    void on_loginButton_clicked();

    void on_crudButton_clicked();

private:
    Ui::MainMenuWindow *ui;
    addPixWindow *apw;
    crudPixWindow *cpw;

};

#endif // MAINMENUWINDOW_H

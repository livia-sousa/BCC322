#ifndef ADDPIXWINDOW_H
#define ADDPIXWINDOW_H

#include <QDialog>

namespace Ui {
class addPixWindow;
}

class addPixWindow : public QDialog
{
    Q_OBJECT

public:
    explicit addPixWindow(QWidget *parent = nullptr);
    ~addPixWindow();

private slots:
    void on_cadastrarButton_clicked();

private:
    Ui::addPixWindow *ui;
};

#endif // ADDPIXWINDOW_H

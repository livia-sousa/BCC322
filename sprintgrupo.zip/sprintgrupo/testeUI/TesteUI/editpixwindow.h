#ifndef EDITPIXWINDOW_H
#define EDITPIXWINDOW_H

#include <QDialog>

namespace Ui {
class editPixWindow;
}

class editPixWindow : public QDialog
{
    Q_OBJECT

public:
    explicit editPixWindow(QWidget *parent = nullptr);
    editPixWindow(QWidget *parent = nullptr, int row = 0);
    ~editPixWindow();

    void setSelectedRow(int newSelectedRow);

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::editPixWindow *ui;
    int selectedRow;
};

#endif // EDITPIXWINDOW_H

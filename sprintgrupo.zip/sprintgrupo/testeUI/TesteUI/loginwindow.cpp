#include "loginwindow.h"
#include "ui_loginwindow.h"
#include "../../TesteSimplesPix/pixlist.h"

LoginWindow::LoginWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LoginWindow)
{
    ui->setupUi(this);
    QMainWindow::showFullScreen();
    PixList* instance = PixList::getInstance();

}

LoginWindow::~LoginWindow()
{
    delete ui;
}


void LoginWindow::on_loginButton_clicked()
{
    mmw = new MainMenuWindow(this);
    mmw->show();
}


void LoginWindow::on_sairButton_clicked()
{
    PixList::getInstance()->save();
    close();
}


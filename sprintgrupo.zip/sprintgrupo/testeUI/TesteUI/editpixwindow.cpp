#include "editpixwindow.h"
#include "ui_editpixwindow.h"
#include <QMessageBox>
#include "../../TesteSimplesPix/pixlist.h"

editPixWindow::editPixWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::editPixWindow)
{
    ui->setupUi(this);
}

editPixWindow::editPixWindow(QWidget *parent, int row):
    QDialog(parent),
    ui(new Ui::editPixWindow),
    selectedRow(row)
{
    ui->setupUi(this);
    auto itr = PixList::getInstance()->getList();
    int i = selectedRow;
    while(i != 0){
        ++itr;
        i--;
    }
    ui->nameTextEdit->insertPlainText((*itr)->getName());
    ui->valueTextEdit->insertPlainText(QString::number((*itr)->getValue()));
}

editPixWindow::~editPixWindow()
{
    delete ui;
}

void editPixWindow::on_buttonBox_accepted()
{
    auto itr = PixList::getInstance()->getList();
    int i = selectedRow;
    while(i != 0){
        ++itr;
        i--;
    }
    QString str = ui->nameTextEdit->toPlainText();
    if(str == "")
        QMessageBox::warning(this, "ERRO", "Nome inválido");
    else{
        float value = ui->valueTextEdit->toPlainText().toFloat();
        if(value <= 0)
            QMessageBox::warning(this, "ERRO", "Valor inválido");
        else{
            (*itr)->setName(str);
            (*itr)->setValue(value);
            QMessageBox::information(this, "EDITAR PIX", "PIX EDITADO COM SUCESSO");
            close();
        }
    }
}

void editPixWindow::setSelectedRow(int newSelectedRow){
    selectedRow = newSelectedRow;
}


void editPixWindow::on_buttonBox_rejected()
{
    close();
}


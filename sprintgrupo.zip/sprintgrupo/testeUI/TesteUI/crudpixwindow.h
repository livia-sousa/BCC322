#ifndef CRUDPIXWINDOW_H
#define CRUDPIXWINDOW_H

#include <QMainWindow>
#include "editpixwindow.h"

namespace Ui {
class crudPixWindow;
}

class crudPixWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit crudPixWindow(QWidget *parent = nullptr);
    ~crudPixWindow();

private slots:
    void on_tableWidget_cellDoubleClicked(int row, int column);

    void on_removerButton_clicked();

private:
    Ui::crudPixWindow *ui;
    editPixWindow *epw;
};

#endif // CRUDPIXWINDOW_H

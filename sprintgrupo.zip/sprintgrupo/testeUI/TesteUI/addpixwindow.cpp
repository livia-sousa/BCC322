#include "addpixwindow.h"
#include "ui_addpixwindow.h"
#include <QString>
#include <iostream>
#include <QDateTime>
#include <QMessageBox>
#include "../../TesteSimplesPix/pix.h"
#include "../../TesteSimplesPix/pixlist.h"

addPixWindow::addPixWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addPixWindow)
{
    ui->setupUi(this);
}

addPixWindow::~addPixWindow()
{
    delete ui;
}

void addPixWindow::on_cadastrarButton_clicked()
{
    QString str = ui->nameTextEdit->toPlainText();
    if(str == "")
        QMessageBox::warning(this, "ERRO", "Nome inválido");
    else{
        float value = ui->valueTextEdit->toPlainText().toFloat();
        if(value <= 0)
            QMessageBox::warning(this, "ERRO", "Valor inválido");
        else{
            PixList::createPix(QDateTime::currentDateTime(), value, str);
            QMessageBox::information(this, "CADASTRAR PIX", "PIX CADASTRADO COM SUCESSO");
            close();
        }
    }
}

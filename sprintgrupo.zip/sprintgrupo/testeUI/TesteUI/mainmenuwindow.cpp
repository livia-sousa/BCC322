#include "mainmenuwindow.h"
#include "ui_mainmenuwindow.h"
#include <QMessageBox>
#include "../../TesteSimplesPix/pixlist.h"
#include <QFile>

MainMenuWindow::MainMenuWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainMenuWindow)
{
    ui->setupUi(this);
    QMainWindow::showFullScreen();
}

MainMenuWindow::~MainMenuWindow()
{
    delete ui;
}

void MainMenuWindow::on_loginButton_3_clicked()
{
    apw = new addPixWindow(this);
    apw->setWindowModality(Qt::ApplicationModal);
    apw->show();
}


void MainMenuWindow::on_loginButton_clicked()
{
    QString filename = "../TesteUI/bin/relatorio.csv";
    QFile file(filename);
    if(file.open(QFile::WriteOnly |QFile::Truncate))
    {
        QTextStream output(&file);

        output << "DATA;NOME;VALOR\n";
        for(auto p = PixList::getInstance()->getList(); p != PixList::getInstance()->getEndList(); ++p)
            output << (*p)->getData().toString("dd/MM/yyyy HH:mm") + ";" + (*p)->getName() + ";R$ " + QString::number((*p)->getValue()) + "\n";
    }
    QMessageBox::information(this, "GERAR RELATÓRIO", "RELATÓRIO GERADO COM SUCESSO");
}


void MainMenuWindow::on_crudButton_clicked()
{
    cpw = new crudPixWindow(this);
    cpw->show();
}


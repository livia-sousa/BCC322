#ifndef PIX_H
#define PIX_H

#include <QObject>
#include <QDateTime>
#include <QString>

class Pix : public QObject
{
    Q_OBJECT
/*
protected:
    QDateTime data;
    float value;
    QString name;
*/
public:
    /*
    Pix();
    Pix(QDateTime d, float v, QString n);
    */
    virtual ~Pix();
    Pix& operator=(const Pix& rhs);

    //static Pix& createPix(QDateTime d = QDateTime::currentDateTime(), float v = 0.0, QString n = "");
    virtual QDateTime getData() = 0;
    virtual void setData(QDateTime n) = 0;
    virtual float getValue() = 0;
    virtual void setValue(float n) = 0;
    virtual QString getName() = 0;
    virtual void setName(QString n) = 0;


signals:

};

#endif // PIX_H

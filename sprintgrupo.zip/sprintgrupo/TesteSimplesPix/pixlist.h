#ifndef PIXLIST_H
#define PIXLIST_H
using namespace std;
#include <vector>
#include "pix.h"

class PixList
{
public:
    static PixList* getInstance();
    virtual ~PixList();
    static Pix& createPix(QDateTime d = QDateTime::currentDateTime(), float v = 0.0, QString n = "");
    vector<Pix*>::iterator getList();
    vector<Pix*>::iterator getEndList();
    int size();
    void save();
    void erase(vector<Pix*>::iterator);
private:
    static vector <Pix*> List;
    static  PixList* instance;
    PixList();
    PixList(PixList&);
    void operator=(PixList&);
};

#endif // PIXLIST_H

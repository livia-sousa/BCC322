#include <QtTest>
#include "../pix.h"
#include "../pixlist.h"

class TestPix : public QObject
{
    Q_OBJECT

public:
    TestPix();
    ~TestPix();

private slots:
    void constructor();
    void getData();
    void setData();
    void getValue();
    void setValue();
    void getName();
    void setName();

};

TestPix::TestPix()
{

}

TestPix::~TestPix()
{

}

void TestPix::constructor(){
    PixList* list = PixList::getInstance();
    Pix& p1 = Pix::createPix();
    QDateTime data(QDate(2022, 06, 10), QTime(12, 52));
    Pix& p2 = Pix::createPix(data, 100.00, "Fulano da Silva");
    QVERIFY((p1.getData().daysTo(QDateTime::currentDateTime()) >= 0) && (fabs(p1.getValue()) < 0.001) && (p1.getName() == ""));
    QVERIFY(p2.getData().daysTo(data) == 0 && fabs(p2.getValue()- 100.00) < 0.001 && p2.getName() == "Fulano da Silva");
}
void TestPix::getData(){
    QDateTime data(QDate(2022, 06, 10), QTime(12, 52));
    Pix& p2 = Pix::createPix(data, 100.00, "Fulano da Silva");
    QDateTime test(p2.getData());
    QVERIFY(test.toString() == "Fri Jun 10 12:52:00 2022");
}
void TestPix::setData(){
    Pix& p1 = Pix::createPix();
    QDateTime data(QDate(2022, 06, 10), QTime(12, 52));
    p1.setData(data);
    QVERIFY(p1.getData().toString() == "Fri Jun 10 12:52:00 2022");
}
void TestPix::getValue(){
    QDateTime data(QDate(2022, 06, 10), QTime(12, 52));
    Pix& p2 = Pix::createPix(data, 100.00, "Fulano da Silva");
    float test(p2.getValue());
    QVERIFY(fabs(test - 100.00) < 0.001);
}
void TestPix::setValue(){
    Pix& p1 = Pix::createPix();
    float value = 100.00;
    p1.setValue(value);
    QVERIFY(fabs(p1.getValue() - value) < 0.001);
}
void TestPix::getName(){
    QDateTime data(QDate(2022, 06, 10), QTime(12, 52));
    Pix& p2 = Pix::createPix(data, 100.00, "Fulano da Silva");
    QString test(p2.getName());
    QVERIFY(test == "Fulano da Silva");
}
void TestPix::setName(){
    Pix& p1 = Pix::createPix();
    QString name = "Fulano da Silva";
    p1.setName(name);
    QVERIFY(p1.getName() == "Fulano da Silva");
}
QTEST_APPLESS_MAIN(TestPix)

#include "tst_testpix.moc"

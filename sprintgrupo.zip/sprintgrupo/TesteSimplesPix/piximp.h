#ifndef PIXIMP_H
#define PIXIMP_H

#include "pix.h"

class PixImp : public Pix{
protected:
    QDateTime data;
    float value;
    QString name;
public:
    PixImp();
    PixImp(QDateTime d, float v, QString n);
    //static Pix& createPix(QDateTime d, float v, QString n);
    virtual ~PixImp();
    QDateTime getData();
    void setData(QDateTime n);
    float getValue();
    void setValue(float n);
    QString getName();
    void setName(QString n);
};

#endif // PIXIMP_H

#include "piximp.h"
/*
Pix& PixImp::createPix(QDateTime d, float v, QString n){
    Pix* p = new PixImp(d, v, n);
    return *p;
}

Pix& Pix::createPix(QDateTime d, float v, QString n){
    return PixImp::createPix(d, v, n);
}
*/

PixImp::PixImp(){
    data = QDateTime::currentDateTime();
    value = 0.0;
    name = "";
}
PixImp::~PixImp(){}
PixImp::PixImp(QDateTime d, float v, QString n){
    data = d;
    value = v;
    name = n;
}
QDateTime PixImp::getData(){
    return data;
}
void PixImp::setData(QDateTime n){
    data = n;
}
float PixImp::getValue(){
    return value;
}
void PixImp::setValue(float n){
    value = n;
}
QString PixImp::getName(){
    return name;
}
void PixImp::setName(QString n){
    name = n;
}

#ifndef TESTPIX_H
#define TESTPIX_H

#include <QObject>
#include <QtTest/QTest>
class TestPix : public QObject
{
    Q_OBJECT
public:
    explicit TestPix(QObject *parent = nullptr);

private slots:
    void constructor();
    void getData();
    void setData();
    void getValue();
    void setValue();
    void getName();
    void setName();

};

#endif // TESTPIX_H

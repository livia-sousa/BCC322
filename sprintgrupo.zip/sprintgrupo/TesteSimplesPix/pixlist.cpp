#include "pixlist.h"
#include "piximp.h"
#include <cstdlib>
#include <iostream>
#include <QFile>
PixList* PixList::instance = nullptr;
vector <Pix*> PixList::List;

PixList *PixList::getInstance(){
    if(instance == nullptr){
        instance = new PixList();
    }
    return instance;
}

PixList::~PixList(){
    for(auto p : List){
        delete p;
    }
    delete instance;
    instance = nullptr;
}

Pix& PixList::createPix(QDateTime d, float v, QString n){
    Pix* p = new PixImp(d, v, n);
    List.push_back(p);
    return *p;
}

vector<Pix*>::iterator PixList::getList()
{
    return List.begin();
}

vector<Pix*>::iterator PixList::getEndList()
{
    return List.end();
}

int PixList::size()
{
    return List.size();
}

void PixList::save(){
    QString filename = "../TesteUI/bin/bancodedados.txt";
    QFile file(filename);
    if(file.open(QFile::WriteOnly |QFile::Truncate)){
        QTextStream output(&file);
        for(auto p = PixList::getInstance()->getList(); p != PixList::getInstance()->getEndList(); ++p){
            output << (*p)->getData().toString("dd/MM/yyyy HH:mm") + "\n";
            output << (*p)->getName() + "\n";
            output << QString::number((*p)->getValue()) + "\n";
        }
        file.close();
    }
}

void PixList::erase(vector<Pix*>::iterator itr){
    List.erase(itr);
}

PixList::PixList(){
    List.clear();
    QString filename = "../TesteUI/bin/bancodedados.txt";
    QFile file(filename);
    if(file.open(QFile::ReadOnly)){
        QTextStream in(&file);
        while (!in.atEnd()){
            QString line = in.readLine();
            QDateTime data = QDateTime::fromString(line, "dd/MM/yyyy HH:mm");
            line = in.readLine();
            QString name = line;
            line = in.readLine();
            float value = line.toFloat();
            PixList::createPix(data, value, name);
        }
        file.close();
    }
}

#include "pix.h"
/*
Pix::Pix(){
    data = QDateTime::currentDateTime();
    value = 0.0;
    name = "";
}
*/
Pix::~Pix(){}
/*
Pix::Pix(QDateTime d, float v, QString n){
    data = d;
    value = v;
    name = n;
}
*/
/*
Pix& Pix::operator=(const Pix& rhs){
    if(this != &rhs){
        data = rhs.data;
        value = rhs.value;
        name = rhs.name;
    }
    return *this;
}
*/
/*
QDateTime Pix::getData(){
    return data;
}
void Pix::setData(QDateTime n){
    data = n;
}
float Pix::getValue(){
    return value;
}
void Pix::setValue(float n){
    value = n;
}
QString Pix::getName(){
    return name;
}
void Pix::setName(QString n){
    name = n;
}
*/

﻿1) Estude as aplicações A1_QTestsCommandLine, A2_QTestProject, A3_QTestsGUI
2) Implemente cenarios de testes para a calculadora 
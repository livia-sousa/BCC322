1) Estude as aplicações FirstWidgetApp, SecondWidgetApp, ThirdWidgetApp
2) Melhore a arquitetura da aplicação "ThirdWidgetApp", fazendo com que ambas as janelas sejam apresentadas assincronamente com o método "show() e ainda assim, a caixa de dialgo de "login" impeça o acesso à calculadora
 